#!/usr/bin/env python3
"""
DE Agent - GitOps Deployment Flow (v3)
- Numbered steps showing deployment sequence
- GitHub PR review as approval mechanism
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.generic.database import SQL
from diagrams.generic.storage import Storage
from diagrams.onprem.vcs import Github
from diagrams.onprem.ci import GithubActions
from diagrams.aws.general import User

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - GitOps Deployment Flow",
    filename="output/06_deployment_flow",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Step 1: Agent Generates
    with Cluster("Step 1: Agent Generates", graph_attr=cluster_style("#E8EAF6", "#283593")):
        supervisor = Sagemaker("Supervisor\n(Agent)")
        artifacts = S3("Artifacts\n(S3)")

    # Step 2: Raise PR
    with Cluster("Step 2: Raise PR", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        pr_tool = Lambda("PR Tool\n(Action Group)")
        github = Github("GitHub")
        github_pr = Github("PR #1247")

    # Step 3: Approval via GitHub
    with Cluster("Step 3: GitHub PR Review", graph_attr=cluster_style("#FFF9C4", "#F9A825")):
        review_ddl = Storage("Review:\nDDL")
        review_rollback = Storage("Review:\nRollback")

    # Step 4: CI/CD
    with Cluster("Step 4: CI/CD", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        gh_actions = GithubActions("GitHub\nActions")
        liquibase = Lambda("Liquibase")

    # Step 5: Snowflake DEV
    with Cluster("Step 5: Snowflake DEV", graph_attr=cluster_style("#E0F7FA", "#00838F")):
        sf_dev = SQL("DEV")
        sf_tables = SQL("Tables")
        sf_streams = SQL("Streams")
        sf_tasks = SQL("Tasks")

    # Step 6: Verify
    with Cluster("Step 6: Verify", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        developer = User("Developer")
        test_flow = Storage("Test\nData Flow")

    # PROD (out of scope)
    with Cluster("PROD (Out of Scope)", graph_attr=cluster_style("#F5F5F5", "#9E9E9E")):
        prod = SQL("PROD")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED DEPLOYMENT FLOW ==========

    # 1. Agent generates artifacts
    supervisor >> Edge(label="1. Generate") >> artifacts

    # 2. Artifacts to PR Tool
    artifacts >> Edge(label="2") >> pr_tool

    # 3. PR creation
    pr_tool >> Edge(label="3. git push", style="bold") >> github
    github >> Edge(label="4") >> github_pr

    # 5-6. PR Review
    github_pr >> Edge(label="5. Review") >> review_ddl
    github_pr >> Edge(label="6. Review") >> review_rollback

    # 7. Approve
    review_ddl >> Edge(label="7. Approve", color="green") >> github_pr

    # 8. Merge triggers CI/CD
    github_pr >> Edge(label="8. Merge", style="bold", color="red") >> gh_actions

    # 9-10. CI/CD deployment
    gh_actions >> Edge(label="9") >> liquibase
    liquibase >> Edge(label="10. Deploy", style="bold", color="green") >> sf_dev

    # 11. Snowflake objects created
    sf_dev >> Edge(label="11a") >> sf_tables
    sf_dev >> Edge(label="11b") >> sf_streams
    sf_dev >> Edge(label="11c") >> sf_tasks

    # 12. Developer verification
    sf_dev >> Edge(label="12", style="dashed") >> developer
    developer >> Edge(label="13. Verify") >> test_flow

    # 14. PROD promotion (out of scope)
    test_flow >> Edge(label="14. If OK", style="dashed", color="gray") >> prod

    # Logging
    pr_tool >> Edge(style="dotted", color="gray") >> cw_logs
    liquibase >> Edge(style="dotted", color="gray") >> cw_logs
