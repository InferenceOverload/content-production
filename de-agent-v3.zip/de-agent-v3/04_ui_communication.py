#!/usr/bin/env python3
"""
DE Agent - UI & Communication Architecture (v3)
- Numbered steps showing complete request/response cycle
- Human-in-the-loop SSE streaming with confirmation
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.database import Dynamodb
from diagrams.aws.network import CloudFront, ALB
from diagrams.aws.security import WAF
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.saas.identity import Auth0
from diagrams.aws.general import User

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - UI & Communication Architecture",
    filename="output/04_ui_communication",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Browser - Human in the Loop
    with Cluster("Browser (Human-in-the-Loop)", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        developer = User("Developer")
        react_app = S3("React App")

    # Authentication
    with Cluster("Authentication", graph_attr=cluster_style("#FFEBEE", "#C62828")):
        azure_ad = Auth0("Azure AD\n(Auth0)")

    # CDN Layer
    with Cluster("CloudFront (CDN)", graph_attr=cluster_style("#FFF3E0", "#E65100")):
        cdn = CloudFront("CloudFront")
        waf = WAF("WAF")
        s3_static = S3("S3 Static\nFiles")
        alb = ALB("ALB")

    # API Layer
    with Cluster("API Layer", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        api_lambda = Lambda("Lambda\n(Mangum + FastAPI)")
        with Cluster("Endpoints"):
            ep_chat = Lambda("/api/chat")
            ep_upload = Lambda("/api/upload")

    # Bedrock AgentCore
    with Cluster("Bedrock AgentCore", graph_attr=cluster_style("#E8EAF6", "#283593")):
        supervisor = Sagemaker("Supervisor\nAgent")
        session_memory = Dynamodb("Session\nMemory")

    # Storage
    s3_uploads = S3("S3 Upload\nBucket")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED FLOW WITH HUMAN-IN-LOOP ==========

    # 1-3. Authentication
    developer >> Edge(label="1. Open App") >> react_app
    react_app >> Edge(label="2. Login") >> azure_ad
    azure_ad >> Edge(label="3. JWT Token") >> react_app

    # 4-6. Load static UI
    react_app >> Edge(label="4. Load UI") >> cdn
    cdn >> waf
    waf >> Edge(label="5. Static") >> s3_static
    s3_static >> Edge(label="6. HTML/JS/CSS") >> react_app

    # 7-8. API request
    react_app >> Edge(label="7. POST /api/chat") >> cdn
    waf >> alb
    alb >> Edge(label="8") >> api_lambda

    # API routing
    api_lambda >> ep_chat
    api_lambda >> ep_upload

    # 9. Invoke agent
    ep_chat >> Edge(label="9. Invoke") >> supervisor

    # Session management
    supervisor >> session_memory

    # 10. HUMAN-IN-LOOP: Agent streams response back
    supervisor >> Edge(label="10. Stream\nResponse", style="bold", color="darkblue") >> ep_chat

    # 11. SSE back to client with confirmation request
    ep_chat >> Edge(label="11. SSE Stream\n+ Confirmation", style="bold", color="darkgreen") >> react_app

    # 12. User confirms/modifies and sends back
    react_app >> Edge(label="12. User Confirms\n(Next Step)", style="bold", color="blue") >> cdn

    # Upload flow
    ep_upload >> Edge(label="Upload") >> s3_uploads

    # Logging
    api_lambda >> Edge(style="dotted", color="gray") >> cw_logs
    supervisor >> Edge(style="dotted", color="gray") >> cw_logs
