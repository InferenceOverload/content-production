#!/usr/bin/env python3
"""
DE Agent Architecture Diagrams - v3
Generate all professional architecture diagrams.

Version 3 Features:
- Numbered flow steps showing control sequence
- Human-in-the-loop: bidirectional communication with confirmations
- Corrected agent names: Snow Object Discovery, Schema Handler
- Orthogonal (straight) lines
- Action Groups inside AgentCore
- Horizontal (LR) orientation

Run: python3 generate_all.py
"""

import subprocess
import os
import sys

DIAGRAMS = [
    ("01_complete_architecture.py", "Complete System Architecture"),
    ("02_supervisor_flow.py", "Supervisor Coordination Flow"),
    ("03_specialized_agents.py", "Specialized Agents Detail"),
    ("04_ui_communication.py", "UI & Communication Architecture"),
    ("05_snowflake_data_flow.py", "Snowflake CDC Data Flow"),
    ("06_deployment_flow.py", "GitOps Deployment Flow"),
    ("07_complete_workflow.py", "Complete Workflow (Human-in-the-Loop)"),
    ("08_tool_inventory.py", "Action Groups Inventory"),
]

def check_dependencies():
    """Check if required packages are installed."""
    try:
        import diagrams
        print("diagrams package: OK")
    except ImportError:
        print("ERROR: diagrams package not found. Install with: pip install diagrams")
        return False

    result = subprocess.run(["which", "dot"], capture_output=True, text=True)
    if result.returncode != 0:
        print("ERROR: graphviz not found. Install with: brew install graphviz")
        return False
    print("graphviz: OK")

    return True

def main():
    print("=" * 60)
    print("DE Agent Architecture Diagrams - v3")
    print("=" * 60)
    print()
    print("Features:")
    print("  - Numbered flow steps")
    print("  - Human-in-the-loop confirmations")
    print("  - Corrected agent names")
    print("  - Horizontal (LR) orientation")
    print()

    print("Checking dependencies...")
    if not check_dependencies():
        sys.exit(1)
    print()

    os.makedirs("output", exist_ok=True)
    script_dir = os.path.dirname(os.path.abspath(__file__))

    success_count = 0
    failed = []

    for filename, description in DIAGRAMS:
        print(f"Generating: {description}")
        print(f"  File: {filename}")

        filepath = os.path.join(script_dir, filename)
        result = subprocess.run(
            [sys.executable, filepath],
            capture_output=True,
            text=True,
            cwd=script_dir
        )

        if result.returncode != 0:
            print(f"  ERROR: {result.stderr}")
            failed.append(filename)
        else:
            print(f"  SUCCESS")
            success_count += 1
        print()

    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Total diagrams: {len(DIAGRAMS)}")
    print(f"Successful: {success_count}")
    print(f"Failed: {len(failed)}")

    if failed:
        print("\nFailed diagrams:")
        for f in failed:
            print(f"  - {f}")

    print(f"\nOutput directory: {os.path.join(script_dir, 'output')}")

    output_dir = os.path.join(script_dir, "output")
    if os.path.exists(output_dir):
        files = sorted(os.listdir(output_dir))
        if files:
            print("\nGenerated files:")
            for f in files:
                filepath = os.path.join(output_dir, f)
                size = os.path.getsize(filepath)
                print(f"  - {f} ({size:,} bytes)")

if __name__ == "__main__":
    main()
