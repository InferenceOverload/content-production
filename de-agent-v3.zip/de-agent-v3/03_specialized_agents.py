#!/usr/bin/env python3
"""
DE Agent - Specialized Agents Detail (v3)
- Corrected names: Snow Object Discovery, Schema Handler
- Numbered flow showing execution order
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.aws.security import SecretsManager
from diagrams.generic.database import SQL
from diagrams.generic.storage import Storage

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Specialized Agents Detail",
    filename="output/03_specialized_agents",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # 1. Snow Object Discovery Agent
    with Cluster("1. Snow Object Discovery Agent", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        disc_agent = Sagemaker("Expert:\nSnowflake Metadata")
        with Cluster("Action Group"):
            disc_ag = Lambda("SF Query")
        disc_output = Storage("Output:\nTables, Streams\nTasks, DDL")

    # 2. Alignment Agent
    with Cluster("2. Alignment Agent", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        align_agent = Sagemaker("Expert:\nSemantic Mapping")
        with Cluster("Action Group"):
            align_ag = Lambda("Cortex Embed")
        align_output = Storage("Output:\nColumn->Domain\nMappings")

    # 3. Schema Handler Agent
    with Cluster("3. Schema Handler Agent", graph_attr=cluster_style("#FFF3E0", "#E65100")):
        schema_agent = Sagemaker("Expert:\nDDL Best Practices")
        with Cluster("Action Group"):
            schema_ag = Lambda("Diff")
        schema_output = Storage("Output:\nCREATE TABLE\nALTER TABLE")

    # 4. Pipeline Design Agent
    with Cluster("4. Pipeline Design Agent", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        pipe_agent = Sagemaker("Expert:\nCDC/MERGE Patterns")
        with Cluster("Action Group"):
            pipe_ag = Lambda("Diff")
        pipe_output = Storage("Output:\nCREATE STREAM\nCREATE TASK")

    # Snowflake (Read-Only)
    with Cluster("Snowflake (Read-Only)", graph_attr=cluster_style("#E0F7FA", "#00838F")):
        sf_metadata = SQL("Metadata")
        sf_cortex = SQL("Cortex")

    # Secrets Manager
    secrets = SecretsManager("Secrets Manager\n(Snowflake Creds)")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED CONNECTIONS ==========

    # Agent 1: Snow Object Discovery flow
    disc_agent >> Edge(label="1a") >> disc_ag
    disc_ag >> Edge(label="1b") >> disc_output
    disc_ag >> Edge(label="1c. Read") >> sf_metadata

    # Agent 2: Alignment flow
    align_agent >> Edge(label="2a") >> align_ag
    align_ag >> Edge(label="2b") >> align_output
    align_ag >> Edge(label="2c. Embed") >> sf_cortex

    # Agent 3: Schema Handler flow
    schema_agent >> Edge(label="3a") >> schema_ag
    schema_ag >> Edge(label="3b") >> schema_output

    # Agent 4: Pipeline Design flow
    pipe_agent >> Edge(label="4a") >> pipe_ag
    pipe_ag >> Edge(label="4b") >> pipe_output

    # Secrets access
    disc_ag >> Edge(style="dotted") >> secrets
    align_ag >> Edge(style="dotted") >> secrets
    secrets >> Edge(style="dotted", label="Creds") >> sf_metadata

    # Logging
    disc_ag >> Edge(style="dotted", color="gray") >> cw_logs
    align_ag >> Edge(style="dotted", color="gray") >> cw_logs
    schema_ag >> Edge(style="dotted", color="gray") >> cw_logs
    pipe_ag >> Edge(style="dotted", color="gray") >> cw_logs
