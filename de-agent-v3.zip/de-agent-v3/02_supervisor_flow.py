#!/usr/bin/env python3
"""
DE Agent - Supervisor Coordination Flow (v3)
- Numbered flow steps
- Human-in-the-loop confirmation at each checkpoint
- Corrected agent names: Snow Object Discovery, Schema Handler
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.database import Dynamodb
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.generic.storage import Storage
from diagrams.onprem.vcs import Github
from diagrams.aws.general import User

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Supervisor Coordination Flow",
    filename="output/02_supervisor_flow",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Input - Developer with Human-in-Loop
    with Cluster("Human-in-the-Loop", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        developer = User("Developer")
        mapping_doc = Storage("Mapping Doc\n+ Requirements")

    # AgentCore with Supervisor
    with Cluster("Amazon Bedrock AgentCore", graph_attr=cluster_style("#E8EAF6", "#283593")):
        supervisor = Sagemaker("Supervisor\n(Claude)")
        state_manager = Dynamodb("State\nManager")

        with Cluster("Specialized Agents", graph_attr=cluster_style("#BBDEFB", "#1976D2")):
            discovery = Sagemaker("Snow Object\nDiscovery")
            alignment = Sagemaker("Alignment")
            schema = Sagemaker("Schema\nHandler")
            pipeline = Sagemaker("Pipeline\nDesign")

        with Cluster("Action Groups", graph_attr=cluster_style("#D1C4E9", "#512DA8")):
            ag_parse = Lambda("Parse")
            ag_generate = Lambda("Generate")
            ag_pr = Lambda("PR Tool")

    # Agent Outputs with Checkpoints
    with Cluster("Outputs & Checkpoints", graph_attr=cluster_style("#C8E6C9", "#388E3C")):
        out_existing = Storage("1. Existing\nObjects")
        out_mappings = Storage("2. Column\nMappings")
        out_table_ddl = Storage("3. Table\nDDL")
        out_stream_ddl = Storage("4. Stream/Task\nDDL")

    # Assembled Output
    with Cluster("Final Artifacts", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        changelog = Storage("changelog.yaml")
        sql_files = Storage("*.sql")
        readme = Storage("README.md")

    # Output - GitHub PR
    with Cluster("Output", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        github_pr = Github("GitHub PR")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED FLOW WITH HUMAN-IN-LOOP ==========

    # Step 1: Developer sends request
    developer >> Edge(label="1. Request", style="bold") >> supervisor
    mapping_doc >> Edge(label="2. Upload") >> ag_parse

    # Supervisor manages state
    supervisor >> state_manager

    # Step 3-6: Supervisor routes to agents
    supervisor >> Edge(label="3. Route") >> discovery
    supervisor >> Edge(label="4. Route") >> alignment
    supervisor >> Edge(label="5. Route") >> schema
    supervisor >> Edge(label="6. Route") >> pipeline

    # Agent outputs
    discovery >> Edge(label="7") >> out_existing
    alignment >> Edge(label="8") >> out_mappings
    schema >> Edge(label="9") >> out_table_ddl
    pipeline >> Edge(label="10") >> out_stream_ddl

    # HUMAN-IN-LOOP: Each checkpoint returns to developer for confirmation
    out_existing >> Edge(label="11. Confirm?", style="bold", color="darkgreen") >> developer
    out_mappings >> Edge(label="12. Confirm?", style="bold", color="darkgreen") >> developer
    out_table_ddl >> Edge(label="13. Confirm?", style="bold", color="darkgreen") >> developer
    out_stream_ddl >> Edge(label="14. Confirm?", style="bold", color="darkgreen") >> developer

    # Developer confirms, continues to generate
    developer >> Edge(label="15. Approved", style="bold", color="blue") >> ag_generate

    # Generate creates artifacts
    ag_generate >> Edge(label="16") >> changelog
    ag_generate >> Edge(label="17") >> sql_files
    ag_generate >> Edge(label="18") >> readme

    # Final confirmation before PR
    changelog >> Edge(label="19. Final Review", style="bold", color="darkgreen") >> developer

    # Developer approves PR creation
    developer >> Edge(label="20. Create PR", style="bold", color="blue") >> ag_pr
    ag_pr >> Edge(label="21", style="bold") >> github_pr

    # Logging
    supervisor >> Edge(style="dotted", color="gray") >> cw_logs
