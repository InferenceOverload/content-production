#!/usr/bin/env python3
"""
DE Agent - Complete Workflow with Checkpoints (v3)
- Numbered steps showing complete workflow
- STRONG emphasis on Human-in-the-Loop at each checkpoint
- Corrected agent names
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.generic.storage import Storage
from diagrams.onprem.vcs import Github
from diagrams.aws.general import User

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.5",
    "ranksep": "0.8",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "12",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Complete Workflow (Human-in-the-Loop)",
    filename="output/07_complete_workflow",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Human-in-the-Loop (Developer)
    with Cluster("HUMAN-IN-THE-LOOP", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        developer = User("Developer\n(Confirms Each Step)")
        mapping_doc = Storage("Mapping Doc\n+ Requirements")

    # Step 1: Parse
    with Cluster("Step 1: Parse", graph_attr=cluster_style("#ECEFF1", "#455A64")):
        parse_ag = Lambda("Parse\n(Action Group)")
        cp1 = Storage("Checkpoint 1:\nParsed Data")

    # Step 2: Discover
    with Cluster("Step 2: Discover", graph_attr=cluster_style("#E0F7FA", "#00838F")):
        discovery_agent = Sagemaker("Snow Object\nDiscovery")
        cp2 = Storage("Checkpoint 2:\nExisting Objects")

    # Step 3: Align
    with Cluster("Step 3: Align", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        alignment_agent = Sagemaker("Alignment\nAgent")
        cp3 = Storage("Checkpoint 3:\nMappings")

    # Step 4: Design
    with Cluster("Step 4: Design", graph_attr=cluster_style("#FFF3E0", "#E65100")):
        schema_agent = Sagemaker("Schema\nHandler")
        pipeline_agent = Sagemaker("Pipeline\nDesign")
        cp4 = Storage("Checkpoint 4:\nDDL")

    # Step 5: Generate
    with Cluster("Step 5: Generate", graph_attr=cluster_style("#D1C4E9", "#512DA8")):
        generate_ag = Lambda("Generate\n(Action Group)")
        changelog = Storage("changelog.yaml")
        sql_files = Storage("*.sql")
        cp5 = Storage("Checkpoint 5:\nArtifacts")

    # Step 6: PR
    with Cluster("Step 6: Create PR", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        pr_ag = Lambda("PR Tool\n(Action Group)")
        github_pr = Github("PR #1247")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED FLOW WITH HUMAN-IN-LOOP EMPHASIS ==========

    # Initial input
    developer >> Edge(label="1. Upload", style="bold") >> mapping_doc
    mapping_doc >> Edge(label="2") >> parse_ag

    # Step 1: Parse -> Checkpoint 1
    parse_ag >> Edge(label="3") >> cp1
    cp1 >> Edge(label="4. CONFIRM?", style="bold", color="darkgreen") >> developer
    developer >> Edge(label="5. APPROVED", style="bold", color="blue") >> discovery_agent

    # Step 2: Discover -> Checkpoint 2
    discovery_agent >> Edge(label="6") >> cp2
    cp2 >> Edge(label="7. CONFIRM?", style="bold", color="darkgreen") >> developer
    developer >> Edge(label="8. APPROVED", style="bold", color="blue") >> alignment_agent

    # Step 3: Align -> Checkpoint 3
    alignment_agent >> Edge(label="9") >> cp3
    cp3 >> Edge(label="10. CONFIRM?", style="bold", color="darkgreen") >> developer
    developer >> Edge(label="11. APPROVED", style="bold", color="blue") >> schema_agent

    # Step 4: Design -> Checkpoint 4
    schema_agent >> Edge(label="12") >> cp4
    pipeline_agent >> Edge(label="13") >> cp4
    cp4 >> Edge(label="14. CONFIRM?", style="bold", color="darkgreen") >> developer
    developer >> Edge(label="15. APPROVED", style="bold", color="blue") >> generate_ag

    # Step 5: Generate -> Checkpoint 5
    generate_ag >> Edge(label="16") >> changelog
    generate_ag >> Edge(label="17") >> sql_files
    changelog >> Edge(label="18") >> cp5
    cp5 >> Edge(label="19. FINAL REVIEW", style="bold", color="darkgreen") >> developer

    # Step 6: User approves PR creation
    developer >> Edge(label="20. CREATE PR", style="bold", color="blue") >> pr_ag
    pr_ag >> Edge(label="21", style="bold") >> github_pr

    # Logging
    parse_ag >> Edge(style="dotted", color="gray") >> cw_logs
    discovery_agent >> Edge(style="dotted", color="gray") >> cw_logs
    generate_ag >> Edge(style="dotted", color="gray") >> cw_logs
