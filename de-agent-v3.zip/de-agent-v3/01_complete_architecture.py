#!/usr/bin/env python3
"""
DE Agent - Complete System Architecture (v3 - Simplified)
- Clean horizontal layout
- Clear numbered flow
- Human-in-the-loop clearly shown
- Reduced complexity for better Graphviz rendering
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.database import Dynamodb
from diagrams.aws.network import CloudFront
from diagrams.aws.security import SecretsManager
from diagrams.aws.ml import Sagemaker
from diagrams.aws.management import Cloudwatch
from diagrams.generic.database import SQL
from diagrams.onprem.vcs import Github
from diagrams.onprem.ci import GithubActions
from diagrams.saas.identity import Auth0
from diagrams.aws.general import User

# Use spline for cleaner curves instead of ortho
graph_attr = {
    "splines": "spline",
    "nodesep": "0.8",
    "ranksep": "2.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150",
    "rankdir": "LR"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "14",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Complete System Architecture",
    filename="output/01_complete_architecture",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # === LAYER 1: User & Auth ===
    with Cluster("1. User & Authentication", graph_attr=cluster_style("#E3F2FD", "#1565C0")):
        developer = User("Developer")
        azure_ad = Auth0("Azure AD")

    # === LAYER 2: UI ===
    with Cluster("2. UI Layer", graph_attr=cluster_style("#FFF3E0", "#E65100")):
        cdn = CloudFront("CloudFront\n+ WAF")
        s3_ui = S3("S3 React")
        api_lambda = Lambda("API Lambda\n(Mangum)")

    # === LAYER 3: AgentCore (Main Focus) ===
    with Cluster("3. Amazon Bedrock AgentCore (Human-in-the-Loop)", graph_attr=cluster_style("#E8EAF6", "#283593")):

        supervisor = Sagemaker("Supervisor\nAgent (Claude)")

        with Cluster("Specialized Agents", graph_attr=cluster_style("#BBDEFB", "#1976D2")):
            agent_discover = Sagemaker("Snow Object\nDiscovery")
            agent_align = Sagemaker("Alignment")
            agent_schema = Sagemaker("Schema\nHandler")
            agent_pipeline = Sagemaker("Pipeline\nDesign")

        with Cluster("Action Groups", graph_attr=cluster_style("#D1C4E9", "#512DA8")):
            ag_parse = Lambda("Parse")
            ag_query = Lambda("SF Query")
            ag_embed = Lambda("Cortex\nEmbed")
            ag_generate = Lambda("Generate")
            ag_pr = Lambda("PR Tool")

        memory = Dynamodb("Memory")

    # === LAYER 4: External Systems ===
    with Cluster("4. Snowflake (Read-Only)", graph_attr=cluster_style("#E0F7FA", "#00838F")):
        sf_meta = SQL("Metadata")
        sf_cortex = SQL("Cortex")

    with Cluster("5. Storage", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        s3_docs = S3("Mapping\nDocs")
        s3_artifacts = S3("Artifacts")

    with Cluster("6. Git & Deploy", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        github = Github("GitHub")
        gh_actions = GithubActions("Actions")
        liquibase = Lambda("Liquibase")

    with Cluster("7. Snowflake DEV", graph_attr=cluster_style("#C8E6C9", "#388E3C")):
        sf_staging = SQL("Staging")
        sf_products = SQL("Products")

    # Secrets & Logging
    secrets = SecretsManager("Secrets")
    cw_logs = Cloudwatch("CloudWatch")

    # ========== NUMBERED FLOW ==========

    # Step 1-2: Auth flow
    developer >> Edge(label="1. Login") >> azure_ad
    azure_ad >> Edge(label="2. Token") >> cdn

    # Step 3: UI
    cdn >> Edge(label="3a") >> s3_ui
    cdn >> Edge(label="3b") >> api_lambda

    # Step 4-5: HUMAN-IN-THE-LOOP (Key Feature!)
    api_lambda >> Edge(label="4. Request", color="blue", style="bold") >> supervisor
    supervisor >> Edge(label="5. Response\n+ CONFIRM?", color="green", style="bold") >> api_lambda

    # Step 6: Supervisor routes to agents
    supervisor >> Edge(label="6a") >> agent_discover
    supervisor >> Edge(label="6b") >> agent_align
    supervisor >> Edge(label="6c") >> agent_schema
    supervisor >> Edge(label="6d") >> agent_pipeline

    # Agents to Action Groups
    agent_discover >> ag_query
    agent_align >> ag_embed
    agent_schema >> ag_generate
    agent_pipeline >> ag_generate
    supervisor >> ag_parse
    supervisor >> ag_pr

    # Memory
    supervisor >> Edge(style="dotted") >> memory

    # Step 7-8: Action Groups to Snowflake
    ag_query >> Edge(label="7. Read") >> sf_meta
    ag_embed >> Edge(label="8. Embed") >> sf_cortex

    # Step 9-10: Storage
    ag_parse >> Edge(label="9") >> s3_docs
    ag_generate >> Edge(label="10") >> s3_artifacts

    # Step 11-14: PR & Deploy flow
    ag_pr >> Edge(label="11. Create PR") >> github
    github >> Edge(label="12. Merge") >> gh_actions
    gh_actions >> Edge(label="13") >> liquibase
    liquibase >> Edge(label="14. Deploy", color="green", style="bold") >> sf_staging
    sf_staging >> sf_products

    # Secrets
    ag_query >> Edge(style="dotted") >> secrets
    ag_embed >> Edge(style="dotted") >> secrets
    ag_pr >> Edge(style="dotted") >> secrets

    # Logging
    supervisor >> Edge(style="dotted", color="gray") >> cw_logs
