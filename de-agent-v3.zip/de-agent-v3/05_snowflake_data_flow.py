#!/usr/bin/env python3
"""
DE Agent - Snowflake CDC Data Flow (v3)
- Numbered flow showing data movement sequence
- All objects created by Liquibase (GitOps)
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.management import Cloudwatch
from diagrams.generic.database import SQL
from diagrams.generic.storage import Storage
from diagrams.onprem.ci import GithubActions

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Snowflake CDC Data Flow",
    filename="output/05_snowflake_data_flow",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Vendor Sources
    with Cluster("1. Vendor Sources", graph_attr=cluster_style("#ECEFF1", "#455A64")):
        vendor_a = Storage("Vendor A\nCSV")
        vendor_b = Storage("Vendor B\nCSV")
        vendor_c = Storage("Vendor C\nCSV")

    # S3 Landing Zone
    s3_landing = S3("2. S3 Landing\nZone")

    # Snowflake - Ingestion
    with Cluster("3. Snowflake - Ingestion", graph_attr=cluster_style("#E0F7FA", "#00838F")):
        ext_stage = SQL("External\nStage")
        stg_a = SQL("stg_vendor_a")
        stg_b = SQL("stg_vendor_b")
        stg_c = SQL("stg_vendor_c")

    # Snowflake - CDC
    with Cluster("4. Snowflake - CDC", graph_attr=cluster_style("#B2EBF2", "#00838F")):
        stream_a = SQL("stream_a")
        stream_b = SQL("stream_b")
        stream_c = SQL("stream_c")
        task_merge = SQL("Consolidated\nTask (MERGE)")

    # Snowflake - Domain
    with Cluster("5. Snowflake - Domain", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        domain_table = SQL("domain.\nfraud_core")

    # Data Products
    with Cluster("6. Data Products", graph_attr=cluster_style("#F3E5F5", "#7B1FA2")):
        product_view = SQL("products.\nfraud_summary\n(VIEW)")
        consumers = Storage("BI/ML\nConsumers")

    # Created by Liquibase
    with Cluster("Created by Liquibase", graph_attr=cluster_style("#FFF9C4", "#F9A825")):
        gh_actions = GithubActions("GitHub\nActions")
        liquibase = Lambda("Liquibase")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED DATA FLOW ==========

    # Step 1: Vendors to S3
    vendor_a >> Edge(label="1a") >> s3_landing
    vendor_b >> Edge(label="1b") >> s3_landing
    vendor_c >> Edge(label="1c") >> s3_landing

    # Step 2: S3 to Stage
    s3_landing >> Edge(label="2. Mount") >> ext_stage

    # Step 3: Stage to staging tables
    ext_stage >> Edge(label="3a. COPY") >> stg_a
    ext_stage >> Edge(label="3b. COPY") >> stg_b
    ext_stage >> Edge(label="3c. COPY") >> stg_c

    # Step 4: Staging to streams (CDC)
    stg_a >> Edge(label="4a. CDC", style="dashed") >> stream_a
    stg_b >> Edge(label="4b. CDC", style="dashed") >> stream_b
    stg_c >> Edge(label="4c. CDC", style="dashed") >> stream_c

    # Step 5: Streams to task
    stream_a >> Edge(label="5a") >> task_merge
    stream_b >> Edge(label="5b") >> task_merge
    stream_c >> Edge(label="5c") >> task_merge

    # Step 6: Task to domain
    task_merge >> Edge(label="6. MERGE", style="bold") >> domain_table

    # Step 7: Domain to product
    domain_table >> Edge(label="7. VIEW") >> product_view

    # Step 8: Product to consumers
    product_view >> Edge(label="8") >> consumers

    # Liquibase deploys all objects
    gh_actions >> liquibase
    liquibase >> Edge(style="dotted", color="red", label="Deploy") >> ext_stage
    liquibase >> Edge(style="dotted", color="red") >> stream_a
    liquibase >> Edge(style="dotted", color="red") >> task_merge
    liquibase >> Edge(style="dotted", color="red") >> domain_table

    # Logging
    liquibase >> Edge(style="dotted", color="gray") >> cw_logs
