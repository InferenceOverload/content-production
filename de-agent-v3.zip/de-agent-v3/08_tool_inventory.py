#!/usr/bin/env python3
"""
DE Agent - Action Groups Inventory (v3)
- Corrected agent names: Snow Object Discovery, Schema Handler
- Numbered connections showing invocation order
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.ml import Sagemaker
from diagrams.aws.security import SecretsManager
from diagrams.aws.management import Cloudwatch
from diagrams.generic.database import SQL
from diagrams.onprem.vcs import Github

graph_attr = {
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.0",
    "fontsize": "14",
    "fontname": "Helvetica Bold",
    "bgcolor": "white",
    "pad": "0.5",
    "dpi": "150"
}

def cluster_style(bgcolor, pencolor):
    return {
        "bgcolor": bgcolor,
        "pencolor": pencolor,
        "penwidth": "2",
        "fontsize": "13",
        "fontname": "Helvetica Bold"
    }

with Diagram(
    "DE Agent - Action Groups Inventory",
    filename="output/08_tool_inventory",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    # Bedrock AgentCore
    with Cluster("Amazon Bedrock AgentCore", graph_attr=cluster_style("#E8EAF6", "#283593")):

        # Agents with corrected names
        with Cluster("Agents", graph_attr=cluster_style("#C5CAE9", "#3949AB")):
            supervisor = Sagemaker("Supervisor")
            discovery = Sagemaker("Snow Object\nDiscovery")
            alignment = Sagemaker("Alignment")
            schema = Sagemaker("Schema\nHandler")
            pipeline = Sagemaker("Pipeline\nDesign")

        # Action Groups
        with Cluster("Action Groups (Lambda)", graph_attr=cluster_style("#D1C4E9", "#512DA8")):
            ag_parse = Lambda("Parse\n(xlsx, csv, pdf)")
            ag_sf_query = Lambda("SF Query\n(metadata)")
            ag_cortex = Lambda("Cortex\nEmbed")
            ag_diff = Lambda("Diff\n(schema)")
            ag_generate = Lambda("Generate\n(Liquibase)")
            ag_pr = Lambda("PR Tool\n(GitHub)")

    # External Systems
    with Cluster("External Systems", graph_attr=cluster_style("#E8F5E9", "#388E3C")):
        s3_docs = S3("S3 Mapping\nDocs")
        sf_readonly = SQL("Snowflake\n(Read-Only)")
        sf_cortex_ext = SQL("Snowflake\nCortex")
        s3_artifacts = S3("S3\nArtifacts")
        github = Github("GitHub")

    # Secrets Manager
    with Cluster("Secrets Manager", graph_attr=cluster_style("#FFEBEE", "#C62828")):
        secret_sf = SecretsManager("Snowflake\n(Read-Only)")
        secret_gh = SecretsManager("GitHub\nToken")

    # CloudWatch
    cw_logs = Cloudwatch("CloudWatch\nLogs")

    # ========== NUMBERED AGENT -> ACTION GROUP CONNECTIONS ==========

    # Supervisor uses Parse, Generate, PR
    supervisor >> Edge(label="1", style="dashed") >> ag_parse
    supervisor >> Edge(label="2", style="dashed") >> ag_generate
    supervisor >> Edge(label="3", style="dashed") >> ag_pr

    # Snow Object Discovery uses SF Query
    discovery >> Edge(label="4", style="dashed") >> ag_sf_query

    # Alignment uses Cortex Embed
    alignment >> Edge(label="5", style="dashed") >> ag_cortex

    # Schema Handler and Pipeline Design use Diff
    schema >> Edge(label="6", style="dashed") >> ag_diff
    pipeline >> Edge(label="7", style="dashed") >> ag_diff

    # Action Groups to External Systems
    ag_parse >> Edge(label="A") >> s3_docs
    ag_sf_query >> Edge(label="B. Read") >> sf_readonly
    ag_cortex >> Edge(label="C. Embed") >> sf_cortex_ext
    ag_generate >> Edge(label="D") >> s3_artifacts
    ag_pr >> Edge(label="E. Create PR") >> github

    # Secrets connections
    ag_sf_query >> Edge(style="dotted") >> secret_sf
    ag_cortex >> Edge(style="dotted") >> secret_sf
    ag_pr >> Edge(style="dotted") >> secret_gh
    secret_sf >> Edge(style="dotted", label="Creds") >> sf_readonly
    secret_gh >> Edge(style="dotted", label="Token") >> github

    # Logging
    ag_parse >> Edge(style="dotted", color="gray") >> cw_logs
    ag_sf_query >> Edge(style="dotted", color="gray") >> cw_logs
    ag_cortex >> Edge(style="dotted", color="gray") >> cw_logs
    ag_generate >> Edge(style="dotted", color="gray") >> cw_logs
    ag_pr >> Edge(style="dotted", color="gray") >> cw_logs
